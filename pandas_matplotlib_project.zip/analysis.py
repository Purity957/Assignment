# Analyzing Data with Pandas & Visualizing with Matplotlib

import pandas as pd
import matplotlib.pyplot as plt

# Task 1: Load and Explore the Dataset

# load dataset (use iris.csv included in this repo)
df = pd.read_csv("iris.csv")

# show first rows
print("First rows of dataset:")
print(df.head())

# check info
print("\nDataset info:")
print(df.info())

# check missing values
print("\nMissing values:")
print(df.isnull().sum())

# clean dataset (drop rows with missing values)
df = df.dropna()

# Task 2: Basic Data Analysis

# statistics
print("\nStatistics:")
print(df.describe())

# group by species and take mean
print("\nGroup by species:")
print(df.groupby("species").mean(numeric_only=True))

# Task 3: Visualization with Matplotlib

# histogram of sepal length
plt.hist(df["sepal_length"], bins=10, color="skyblue", edgecolor="black")
plt.title("Sepal Length Distribution")
plt.xlabel("Sepal Length")
plt.ylabel("Count")
plt.show()

# bar chart of average petal length per species
avg_petal = df.groupby("species")["petal_length"].mean()
avg_petal.plot(kind="bar", color="lightgreen")
plt.title("Average Petal Length by Species")
plt.xlabel("Species")
plt.ylabel("Average Petal Length")
plt.show()

# scatter plot (sepal length vs sepal width)
plt.scatter(df["sepal_length"], df["sepal_width"], color="orange")
plt.title("Sepal Length vs Sepal Width")
plt.xlabel("Sepal Length")
plt.ylabel("Sepal Width")
plt.show()
