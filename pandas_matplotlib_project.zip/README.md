# Pandas & Matplotlib Project

This project shows how to load, clean, analyze, and visualize a dataset using **Pandas** and **Matplotlib**.  
The dataset used is a sample of the **Iris dataset**.

## 📂 Files in this repo
- `analysis.py` → Python script with all tasks (load, clean, analyze, visualize).
- `iris.csv` → Sample dataset (Iris flowers).
- `README.md` → Project description.

## 🚀 How to run
1. Clone the repository
2. Install required libraries:
   ```bash
   pip install pandas matplotlib
   ```
3. Run the script:
   ```bash
   python analysis.py
   ```

## 📊 Tasks covered
1. Load and explore the dataset
2. Basic statistics and grouping
3. Simple data visualizations

